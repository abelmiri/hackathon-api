let domain_url = "http://crmchoopex.ir/"
let restful_url = "http://hackathon.crmchoopex.ir/"
let media_url = "http://hackathon.crmchoopex.ir/files/media/"
let vector_url = "http://hackathon.crmchoopex.ir/files/svg/"
// set these later 👆

// let media_location = "files/media/"
// let vector_location = "files/svg/"
let auth = "QEFiZWxtaXJpIEBIb3NleW5tb3VzYXZp"
let android_token = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhcHBfdHlwZSI6ImFuZHJvaWQifQ.QtdKhREsF7nVYvuWdmXKl7OVI98HKrcOGCK_RLWM9wKs0loypUJrNPbKXyubf0CQ5Jq66gLBden19UL4vfOPKg"
let ios_token = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhcHBfdHlwZSI6ImlvcyJ9.MgdLvXQDCQNMxj86_4VUKqptkVaW2CFBU9BfSWTZkr6yq6gTE5rh6sA1RLXQN7ApwuRChpnEDqFMXpGlc5oVSw"
let sign = "0x410x620x650x6c"
let port = 3000

exports.domain_url = domain_url
exports.restful_url = restful_url
exports.media_url = media_url
exports.vector_url = vector_url
// exports.media_location = media_location
// exports.vector_location = vector_location
exports.auth = auth
exports.android_token = android_token
exports.ios_token = ios_token
exports.sign = sign
exports.port = port